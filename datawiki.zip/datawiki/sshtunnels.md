Setting up ssh tunnels [(back to home)](./README.md)
===================================
To get user please contant Sami Marjokorpi. Send you fi123456 id and request to acess wex and docker servers.

If you want to use ssh, instead of putty, you can add the tunnels with:

`ssh -L 8624:localhost:8624 fi296600@9.134.8.16`

 
### Tunnels to the docker server ###

Create a new session in the putty:

![docker server](./wextunnela.png?raw=true "docker server")

Add all required ports as described below, by clicking add:

![docker server](./wextunnelb.png?raw=true "docker server")

Remember to save the session, so the tunnel settings need to be added only once.

### Tunnels to the wex server ###

Similar to the docker server, add tunnels to the docker server:

![wex server](./wextunnelc.png?raw=true "wex server")

Add all required ports as described below, by clicking add:

![wex server](./wextunneld.png?raw=true "wex server")

and save the session.

 [(back to home)](./README.md)
