# Dictionaries

CSV files  for Nordic languages

CSV format must be:

```
lemma,entity,entity_subtype
eduskunta,Organization
valtioneuvosto,Organization
hallitus,Organization
Suomi,Location,Country

```

Lemma can be regex expression. For example:

```
lemma,entity,entity_subtype
[Ee]duskun\w*,Organization
[vV]altioneuvo\w*,Organization
Suom\w*,Location,Country
```

Value of field 'entity_subtype' is optional, but header must be present.

The tool reads all CSV files in alphabetical order and takes the first match. 
For example: if there are two files *lemma.csv* and *lemma2.csv* and *lemma.csv" includes line ```Suomi,Location``` and *lemma2.csv* includes line ```Suomi,Location,Country```, the line in *lemma.csv* is used.

