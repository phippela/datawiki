Pre-annotation tool  [(back to home)](../README.md)
===================================

WKS pre-annotation tool (for small languages) has been installed on .16 server at port 7000.  
Before you can access please setup [ssh tunnels](../sshtunnels.md).

The documentation for currently installed [pre-annotator tool](./orig.md).

Do note, that if you are using non-WKS supported language, then you cannot train the models with WKS. HOWEVER, what you can do is to use the annotation capabilities. After annotation, one then extracts the annotated data for training carried elsewhere.
These steps are out-of-scope of this documentation.

### pre-annotate material for WKS ###

This is in house build tool made by Sami Salkosuo. With this one can create pre-annotated documents
with dictionaries and udpipe parsers. This tool supports lemma and regexp style. Especially this tool supports
Finnish, Norwegian, Swedish, Danish and English. Do note that version installed has been extended for English support, 
compared to the version [available from git](https://github.ibm.com/sami-salkosuo/preannotator-tool).

Do note that there are possibility of pre-annotation material with dictionaries already in WKS for supported languages (such as English).
Challenge with WKS out-of-the-box pre-annoatation is that some languages are not supported and you can apply only one annotation
(NLU entites OR WKS dictionaries). By making pre-annotation before importing data, one can use varying sources (such as multiple NLU services).

Currently there is no custom code for supporting two NLU services (like NLU entities and NLU dictionaries).

### where to access ###

Tool is pretty straight forward, you can create either lemmas or regexp for specific languages.

`http://localhost:7000`

![preannotator](./preannotator.png?raw=true "preannotator")
 
### how installed ###
 
 The pre-annotatol tool is run as docker container on the .16 server. Currently this is with fi2996600 (TODO make system user).
 
 
 
 [(back to home)](../README.md)
	
