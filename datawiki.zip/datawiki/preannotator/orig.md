# preannotator-tool

Preannotator tool generates annotated documents to be imported to Watson Knowledge Studio.

The tool is packaged as a Docker containers and it includes a simple web UI. Docker container is used because it makes usage and distribution relatively easy. The only requirement is Docker runtime.

## How it works

The basic principle of the tool:

- User selects language, matcher and text files and submits them to server.
- The matcher is regex or lemma.
  - Regex-matcher matches words using Regex.
  - Lemma-matcher matches words to their lemmas
- The server parser each document using UDPipe.
- The server matches documents to regex or lemmas
- For each match, server generates annotation.
- All documents and annotations are packaged as JSON files.
- User downloads JSON files as a zip-file.
- User imports the zip-file to Watson Knowledge Studio.


## Getting started

- Download or clone this repository.
- Requirement:
  - Docker runtime must be installed.
- [Download UDPipe models](udpipe-models-docker/models/README.md)  
- Create UDPipe models Docker image:
  - Go to directory *udpipe-models-docker*
  - Execute: ```docker build -t udpipe-models .``` 
- Create preannotator tool Docker image:
  - Go to directory *preannotator-tool-docker*
  - Execute: ```docker build -t preannotator-tool .``` 
- Run docker image:
  - Go to directory *preannotator-tool-docker*
  - Execute: ```docker run -it --rm -p 8080:8080 preannotator-tool``` 
  - UDPipe models are very large, and when server is started you see text: ```Listening on http://0.0.0.0:8080/ Hit Ctrl-C to quit.```
- Access web UI:
  - Open browser and go to: [http://127.0.0.1:8080](http://127.0.0.1:8080)
- Use the tool by selecting language and select text files to be annotated.
- Upload WKS type system to WKS workspace before importing annotated documents
  - WKS type system: [entity-types.json](preannotator-tool-docker/files/entity_types.json).

### Screenshots

Preannotator tool UI.

![Preannotator tool UI](images/preannotator_tool.png)

The UI shows all dictionaries that are used for regex or lemma matches.

Preannotated documents in Watson Knowledge Studio.

![Annotated docs in WKS](images/wks_preannotatated_docs.png)

### Samples

Directory [./test_data/fi](./test_data/fi/) includes sample text files.

- [This ZIP file includes preannotated documents using Regex-matcher](samples/documents_regex_matcher_20180522065427.zip).
- [This ZIP file includes preannotated documents using Lemma-matcher](samples/documents__lemma_matcher_20180522064700.zip).

## Dictionary CSV files

Dictionaries are given as CSV files for all Nordic languages. See [README.md](preannotator-tool-docker/dictionaries/README.md).

New dictionary CSV files can be added to language specific directories. After adding new CSV files, build Docker image again.

## Development

The server is developed using Python and it uses UDPipe Python bindings.
