# UDPipe model directory

This directory includes UDPipe model files. Files are very large and they are NOT
included in the GitHub repo.

Download models separately:

- Finnish - [https://ibm.box.com/s/kj8cjm4bwh0uqj6lfwiyevunxl6i0n4n](https://ibm.box.com/s/kj8cjm4bwh0uqj6lfwiyevunxl6i0n4n)
- Norwegian - [https://ibm.box.com/s/pdhktlsjsxxntyepuixtjpw3zhu108np](https://ibm.box.com/s/pdhktlsjsxxntyepuixtjpw3zhu108np)
- Swedish model - [https://ibm.box.com/s/j19bayiqnngt47umkwfx6soj6sply0iz](https://ibm.box.com/s/j19bayiqnngt47umkwfx6soj6sply0iz)
- Danish - [https://ibm.box.com/s/e7syku8o3xy56dox4pjcwm683kmdqdlb](https://ibm.box.com/s/e7syku8o3xy56dox4pjcwm683kmdqdlb)

Files must have following names and they must be in this directory:

- fi-model-final.udpipe
- no-model-hyop3.udpipe
- sv-model-embed-hyop1-all.udpipe
- da-model-hyop2.udpipe

