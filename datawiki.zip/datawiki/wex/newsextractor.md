News extractor [(back to importing)](./importingdatatowex.md)
===================================

Here is a sample java application by which one can extract news [discovery-exporter.zip](./discovery-exporter.zip).

The library used is available from git  [watson developer cloud](https://github.com/watson-developer-cloud/java-sdk/tree/master/discovery).

 [(back to importing)](./importingdatatowex.md)