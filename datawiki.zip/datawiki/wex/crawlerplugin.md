WEX crawler plugin [(back to importing)](./importingdatatowex.md)
===================================

Crawler plugin can be used to add new fields to document. In addition one can parse unsupported formats (such discovery new json or
html).

### Where to configure ###
In the WEX admin GUI, go to the collection's crawler configurations:

![plugin configuration](./confplugin.png?raw=true "plugin configuration")

You need to create / re-use some plugin jar, copy it to the server and configure the class name.

### Example source ###

Please find an example [source for a crawler plugin](./CrawlerPlugin.zip). 

This jar [dscrawler.jar](./dscrawler.jar) is needed in the class path.

Here are key parts of the code, where some fields are added:

![Crawler code](./crawlercode.png?raw=true "Crawler code")

### Discovery news json cralwer plugin ###

You can use this [plugin jar](./json-crawler-1.0.jar).

 [(back to importing)](./importingdatatowex.md)