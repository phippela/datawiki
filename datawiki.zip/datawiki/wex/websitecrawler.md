Web site crawler [(back to importing)](./importingdatatowex.md)
===================================

Note! This is just guidelines for own web crawler solution.

### install crawler application ###

Install crawler application to cloud [crawler.zip](./crawler.zip).

### crawlable sites are configured to cloudant ###

Setup sites collection to the cloudant database. Here is an [example site entry](./cloudantsample.txt).

### start cralwing by accessing url ###

Start crawling with `.../start?id=http://nationalinterest.org/`.

The crawling is done with [simplecrawler](https://github.com/simplecrawler/simplecrawler).

### storing crawled sites ###

The crawler filters pages and stores these to discovery. The already crawled urls stored to cloudant url archive.
There is need to do html to text conversion.

 [(back to importing)](./importingdatatowex.md)