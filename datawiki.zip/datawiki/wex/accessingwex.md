WEX basics [(back to WEX)](./wex.md)
===================================

### accessing WEX GUI ###

You can access the WEX Content analytics studio with browser: 

`http://127.0.0.1:8393/ui/analytics`

![WEX gui](./wexgui.png?raw=true "WEX gui")

### accessing WEX admin ###

The user is 'esadmin'/'lumis4de':

`http://127.0.0.1:8390/ESAdmin/loginForm.jsp`

![WEX admin](./wexadmin.png?raw=true "WEX admin")


### starting and stopping ###

Usually the server should be up and running. However, there may have been boot.
Please change to esadmin user and use

`esadmin startall`

![startall](./startall.png?raw=true "startall")

and 

`esadmin stopall`

![stopall](./stopall.png?raw=true "stopall")

commands as needed.

### check that parsers are up and running ###

The servers are running in VMWare, so after starting server one can check that the
finnish parsers respond as follow:

![parser check](./parsercheck.png?raw=true "parser check")

If servers are not responding, please refer to the [Docker server](../parsers/Parsers.md) documentation.

[(back to WEX)](./wex.md)