Importing data [(back to wex)](./wex.md)
===================================

WEX can be bit tricky and there is limited documentation available. If you are first time importing data
please ask help for the setting up. Especially when setting 'small language support' (i.e. Finnish / Swedish)
one may need to change new collections XML configuration.

### getting raw material ###

Best practice is to crawl/extract material to WEX server's data directory. From here material is the 'crawled' into the WEX UIMA pipeline. 

To get data data one can try crawl web or capture tweets by configuring [node red](https://nodered.org/).

One good source for example data is the Discovery's 'News collection'. Articles can be extracted with a custom [news extractor](./newsextractor.md).

Alternative approach is to create own custom [web site crawler](./websitecrawler.md). Note that this is preliminary step before getting files into wex folder, from where WEX 'crawler plugin' can be used to aid in importing data.

### moving files to WEX server ###

Please create own folder on WEX server under:  `/home/esadmin/data`:

![WEX data folder](./datafolder.png?raw=true "WEX data folder")

### setting up collection ###

Setting up collection, importing data and adding facets are described [WEX CAS dictionary help doc](./WEX-servers.docx).

Initial setup process for adding external parsers to WEX pipeline is explained in [wex exercise](./parser-example.pdf). This is here for reference purpose. It describes how the UIMA pipeline is extended in 'small language support'.

First you have to set-up collection with correct language settings. It is highly recommend that each collection should have only one language. When setting up the collection the main consideration is that are you working on WEX out-of-the-box supported languages, or are you using 'UDPipe extended' UIMA pipeline. If you are using 'small language support', then please set-up the collection accordingly.

For 'small language support', we have Finnish and Swedish models that can be used. These are deployed to 'wrapper docker container' to the docker server. Especially on can override Finnish language lemmas with a lemma fix file. Regardless are you parsing content with WEX or WEX Content Analytics Studio, both of the tools pipelines connect to some 'Conllu parser'.

### importing data and crawler plugin ###

If you are using supported 'plain text' format, basic WEX crawlers are sufficient. However, many times one can have format such as json or xml. If this is the case, then one may need to configure a 'crawler plugin'. 

Please refer to 'Crawler plugin' chapter in [WEX CAS dictionary help doc](./WEX-servers.docx).

In addition one often may want to add 'fields' for the WEX documents. These field documents may not be as directly accessible in the UIMA pipeline and the 'facet annotations'. However, when one exports documents for further processing, these fields often contain important information for the use case.

Setting these fields can also be done in here at the crawl time.

Setting up own custom WEX crawler plugin is [described in here](./crawlerplugin.md).

Do note, if you setup a crawler, one may need to do full crawl,  not only rebuild index if wanting to run new indexing for the data set after changes.

 [(back to wex)](./wex.md)