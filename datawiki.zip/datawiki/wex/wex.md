WEX server [(back to home)](../README.md)
===================================
Watson Explorer (Content Analytics) has been installed on .17 server. This is for making demoes and testing WEX easier. 
Before you can access please setup [ssh tunnels](../sshtunnels.md).

### accessing WEX ###

For starting and stopping and URL see [WEX basics](./accessingwex.md).

### getting data into the WEX ###

For crawling data, setting up collection and importing data see [importing data](./importingdatatowex.md).

### configuring UIMA ###

Some tips for creating dictionaries, configuring facets and indexes, adding WKS ML model to WEX and creating custom annotators [some UIMA tips](./uimaconfig.md).

### exporting data to WKS pre-annotation ###

One can pre-annotate material with WEX. This process requires taking export of WEX annotated material and creating own custom ZIP that can be uploaded to WKS.

Steps are described in [exporting annotated data to WKS](./exportfromwex.md).

 [(back to home)](../README.md)