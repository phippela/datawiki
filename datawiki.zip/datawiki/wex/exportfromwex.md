exporting data to WKS [(back to wex)](./wex.md)
===================================
In general Watson Knowledge Studio supports pre-annotation inside the tool. However, there is currently limitation that one can
apply only one kind of annotation. For example, if one wants to annotate with NLU entity recognition and NLU dictionaries, then one should combine the annotations in one pre-annotation that then can be uploaded into WKS.

Alternative option is to use WEX as the pre-annotation tool. The steps are pretty straightforward. The exported type system and XMI documents are added to a ZIP. In addition one needs to map the WEX types to WKS types. 

Before uploading the WKS type system should be in place.

### extracting from WEX ###
If more complex pre-annotation is required, these is option to annotate documents with WEX and then export the material to the WKS. This can be done by adding in here export instruction for the UIMA XMI format:

![Export in parse and index](./parseindex.png?raw=true "Export in parse and index")

Please enable the following:

![Enable XMI export](./xmiexport.png?raw=true "Enable XMI export")

After which one needs to stop and start parse and collection.

To start exporting indexed material, please click the export arrow:

![Starting export](./startexport.png?raw=true "Starting export")

### creating WKS compliant ZIP extract ###

After exporting the material, please create own zip of the following format:

![Zip format](./samplezip.png?raw=true "Zip format")

Especially create a new tab separated text file `cas2di.tsv` to MAP WEX type systems to the WKS type system:

![WEX to WKS type mapping](./typemapping.png?raw=true "WEX to WKS type mapping")

The category mappings are facet mappings (i.e. $.industry marked with red), the other three are the 'out-of-the-box' named entity recognition annotators types. The WEX types (on the left) and WKS typs (on the right) should be separated by 'tab'.

Here is on sample [zip](./extract.zip).
For example in the above, one needs to create (just create entity with the name) types to the WKS, before importing the ZIP.

### Create WKS type system and import the ZIP(s) ###

Before uploading the ZIP, create type system containing types listed in the type system mapping file. This can be just same named entry in general. (like 'INDUSTRY' -> enter in the WKS type system...)

When importing the ZIP, please select the 'UIMA XMI format'. Do note, that if the files are 'too large' or 'too many' there can be timeout. Please split the importing to the WKS to multiple zips just.

 [(back to wex)](./wex.md)