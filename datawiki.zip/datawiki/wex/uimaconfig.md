Configuring UIMA [(back to home)](./wex.md)
===================================
UIMA pipeline is powerful, but quite complex, mechanism for annotating and processing text material.
Available online documentation is limited, especially APIs for custom annotators.

### creating dictionaries ###

In order to create 'lemma' based dictionaries for 'small languages' one should use WEX CAS. After dictionary are configured one deploys the dictionaries from CAS to the WEX collection's UIMA pipeline. Please see [WEX CAS dictionary help doc](./WEX-servers.docx).

Do note that there are alternate approaches one can use for creating 'supported languages'. These include rule based and even simple dictionary from the WEX admin gui. 

This admin gui dictionary is bit restricted and not very easy to configure. Do note that if one puts dictionary entries in lower case, then the matches are case insensitive. One restriction is that one needs to type alternative forms of words, i.e. lemma matching is not supported. However, it is pretty fast to extract words one per line (for example from excel) and import these as dictionaries for a fast POC.

For more complex matching, it is recommended that also for supported languages one should use CAS approach for configuring the UIMA pipeline. 

There also exists [pre-made dictionaries](https://www.ibm.com/developerworks/community/blogs/36db6433-2f12-4533-9c68-489067780bfd/entry/overview3?lang=en) that one can try to use.


### adding facets ###

The facets are not very well described. Basically there is index for entities recognized by WEX. There exists a java class corresponding the event type. Then these indexes entities can be mapped to facets. The mapping can be taking 'behind the scenes' or it can be made explicitly while deploying (or after deploying modifying XML configurations).

When configuring 'facet tree' the mapping from index to facet is made here:

![Facet tree](./facettree.png?raw=true "Facet tree")

After changes one needs to 'deploy analytical resources' from admin gui.

Facets can have different properties, for example, some of the facets can be searchable or used 'behind the scenes'.
The index page can be found under collection analytical resources (drop down) -> details -> index fields:

![WEX index](./wexindex.png?raw=true "WEX index")

As you can see there are many settings. These settings can impact can you use the index in the searches or export it from the WEX.

However, for example when one uses Admin GUI custom dictionaries, one does not need to check the facet index above...
WEX is pretty complex and not very well documented.

### adding machine learning annotators ###

One can also include WKS trained ML annotator to the 'Machine Learning' box:

![ML annotator](./wexml.png?raw=true "ML annotator")

### adding custom annotators ###

In addition, one can write own code for a custom annotation. The CAS image contains example code for custom annotator. There is sample how to add facets/categories that can be configured from text files. These facets can then be mapped to the facet tree.


![Custom Annotator](./customanno.png?raw=true "Custom Annotator")

Creating own custom annotator is roughly made as follows:

1. Locate WEX Content Analytics Studio ecplise IDE
2. Ask for an example project, this exists in pre-made vmware image (needs WIN 10 license)
3. Create own custom annotator, by modifying the code
4. Each of the types have own type class in the UIMA pipeline. These classes need to be included in the project.
5. Extract the project as a jar.
6. Move to the deployment project, and include the custom annotator to the pipeline
7. Deploy the UIMA pipeline with the custom annotator AND map here the custom type classes to the indexes that are then usable in the WEX UIMA. These are created as XML files and can be located also in the WEX server.

The custom annotator operates on CAS object, containing previous annotations. However, there are quite much complexity and process is not well documented. For example, many annotations are not accessible with old API, but one needs to locate the latest.

Do note that process contains pretty many clicks. If you are working first time, it is recommended to ask help. 

Custom annotators are powerful, use cases include adding text file configurable facets, adding coordinates to locations identified by
wex named entity recognition annotator and creating more complex facet / annotators in general.

 [(back to home)](./wex.md)