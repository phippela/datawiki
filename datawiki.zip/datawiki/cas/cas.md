WEX CAS [(back to home)](../README.md)
===================================

It's bit unfortunate that there are so many studios (Knowledge Studio, Watson Studio), 
but in defense of Content Analytics Studio (CAS), it was before model training studio 
or the DSX replacing swizz-army-knife Watson Studio.

If you are making dictionaries, rule based or in general need to programmatically configure UIMA
pipeline, you likely will encounter WEX CAS.

### Starting image ###

You can use `WEXDEMO/WEXDEMO` user to access the image. Please activate the Windows 10 with 
separately bought license.

![Starting CAS](./launchcas.png?raw=true "Starting CAS")

You can install your own, but the pre-made VMWare windows 10 image contains example projects and
pre-configured UIMA pipeline for creating custom dictionaries.

It is good to understand that you can run in CAS similar UIMA pipeline that is installed to the WEX 
server. Especially the image has pipeline that has been configured to parse custom languages with
external parser. Therefore, you need to open ssh tunnel to a parser node OR configure the 
PEAR on desktop (embedded to the pipeline) - to point to an alternative parsers.

### CAS contains also demo custom plugin ###

The project below is the deployment project, where one can configure dictionaires and configure changes to the 
WEX UIMA pipeline.

![CAS Sample](./cassample.png?raw=true "CAS Sample")

The project above is custom annotator, which contains samples how to manipulate 'CASObject', containing the
type system information. It's just bit bad luck that the CAS object and the IDE are called the same.

The custom plugin project is compiled and saved as jar. Then this jar can be 
embedded to the deployment project UIMA pipeline.

### Using of the image is documented in WEX-server.docx ###

Just pay attention that the PEAR used to parse, is actually located on the desktop. You can configure it to point some other 
parser IP as needed.

[WEX CAS dictionary help doc](./WEX-servers.docx)

[(back to home)](../README.md)