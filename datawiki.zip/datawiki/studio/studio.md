Watson Studio [(back to home)](../README.md)
===================================

TODO

![Alt text](../wip.png?raw=true "WEX")

### adding trained model to a discovery collection ###

TODO *simple text in here* as you want.

1. Step A
2. Step B
  
'and some code too'

### visualizing data with 'visual insights ###

TODO *simple text in here* as you want.

[(back to home)](../README.md)
