WKS [(back to home)](../README.md)
===================================
Watson Knowledge Studio is tool for training language ML model. For example, one could train ML model for recognizing
golf words. Passing a plain test to a rest service, would then return identified terms.

The trained model can then be deployed to NLU, Discovery or WEX.

Normal flow is as follows:
1. Data is imported
2. Data is pre-annotated in WKS NLU entities or dictionary
3. Human annotation step is performed
4. Model is trained
5. Model is deployed to Discovery, Waston Studio or to the WEX as ML annotator

### only one WKS pre-annotation allowed ###

Only one WKS pre-annotation can be carried out. If one want's to use both entities and dictionaries, 
pre-annotation meta-data should be added to the uploaded documents.

The before WKS pre-annotation can be carried out for example with WEX, or pre-annotation tool described in this
documentation. 

There is also alternative approach where one uses two NLU services, where one annotates with entities
and the second NLU service instance has dictionaries configured. This approach needs custom application to merge 
and change annotations to the WKS format. However, we do not have this tool yet.

The pre-annotation tool included in the wiki-pages is mainly used in experimental cases, where one wants to use
WKS human annotation step, but does not do the training (for the non supported language) in the WKS tool. Instead
the annotated material is extracted from WKS, and model training is carried out with tools supporting the other languages.
This approach is out-of-scope of these pages.

### Configure type system ###
Before uploading pre-annotated material, the WKS type system should be setup.

![WEX typesystem setup](./wkstypesystem.png?raw=true "WEX typesystem setup")

### Uploading (WEX) pre-annotated documents ###
Drag n drop the pre-annotated zip, and select the UIMA CAS XMI format:

![WEX pre-annotated upload](./wksupload.png?raw=true "WEX pre-annotated upload")

Do note, that if one get's time outs, this can be due to too many or too large documents. If this is the case, 
then one should split the documents in multiple zip files.

### verifying that pre-annotation is successful ###

After starting the annotation step, one can just click any of the documents, and verify that one can find
all pre-annotations.

![Pre-annotated material](./preannowks.png?raw=true "Pre-annotated material")

Do note, that if one uses WEX for the pre-annotation, then it is pretty easy to see how many facets contains interesting data.

### how much data ? ###

Very roughly there should be upwards 50+ examples for different entities. If one has time, more can be added.

### types of human annotation ###

The pre-annotation step described in WEX pre-annotation, adds only entites.
However, WKS supports also co-reference, relations and rules based annotations too.

Co-reference means that there are multiple words referring to the same entity.

Relations are binary relations (for example 'A' is working for 'B).

### deploying trained model to Discovery, NLU (or WEX) ###

If newly trained model, then one should take snapshot. After this one can just select the 'deploy' option.
Please take note of the 'model id' string. This needs to be entered then to the discovery entity 'custom' model field.

![deploying trained model](./wksdeploying.png?raw=true "deploying trained model")

[(back to home)](../README.md)