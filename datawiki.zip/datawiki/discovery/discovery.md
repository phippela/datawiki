DISCOVERY [(back to home)](../README.md)
===================================

We assume that you have trained a WKS Model and have deployed it. You need 'model-id' string, 
in order to configure. WKS will show the 'model-id' string while you deploy the WKS model.

### How to configure uploaded ML model ###

Go to the configurations:

![Edit configuration](./discedit.png?raw=true "Edit configuration")

While testing you can remove other models, than entity. Please click 'Add enrichements':

![Configure enrichements](./testenrich.png?raw=true "Configure enrichements")

Please insert the custom id to the entity:

![Insert custom id](./customid.png?raw=true "Insert custom id")

Now you can enrich you data. For exanmple drop some documents for discovery to go through.

### Verify that uploaded model works ###

You can quickly check from the discovery GUI. 

Please select 'view in schema':

![View in schema](./viewinschema.png?raw=true "View in schema")

And in here, please select entities on left, scroll down and 

![Run entity query](./runquery.png?raw=true "Run entity query")

... you should see matches of the entity types created on the right:

![Type system matches](./matches.png?raw=true "Type system matches")

### Exploring your data with 'visual insights' ###

The visual insight is experimental tool for browsing Discovery collections. So not only news, but your custom made collection
can be browsed with [visual insights](https://visual-insights.bluemix.net/).

On the upper right, there is 'login button' (can be quite dark):

![Login button](./vislogin.png?raw=true "Login button")

This login can be tied to either your IBM external id OR you can invite some external email address and 
grant access to your discovery collection.

Your own collection will appear in the red box.:

![Visual Insights](./visinsights.png?raw=true "Visual Insights")

Please refer to [visual insight documentation](https://visual-insights.bluemix.net/documentation/site/index.html) for details.

[(back to home)](../README.md)
