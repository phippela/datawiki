Simple discovery app [(back to home)](../README.md)
===================================

With this application one can make searches from news collection and click links:

![http://localhost:8000/formula](simpleapp.png?raw=true "http://localhost:8000/formula")

Idea in here is that this is just a simple demo how to integrate with a discovery collection. And if one wants one can modify this for own POC or application.

The application is available from:

[discovery vizualization home](https://developer.ibm.com/tv/building-with-watson-network-visualizations-with-watson-discovery-service/)

There is also youtube presentation about this (app running around 15 mins mark):

[youtube discussion](https://www.youtube.com/watch?v=pcNwV9prfmY)

### how to run ###

Please install python and download from git.

Do note, that you likely need to install requests and flask dependency:

![Imports needed](imports.png?raw=true "Requests and flask needed")

Also it seems that interface has been bit changed, especially the enrichedTitle has been changed to enriched_title.
Check also that you are connecting to the correct instance in the start of the file.

[newsApp.py](./newsApp.py)

[(back to home)](../README.md)

	
