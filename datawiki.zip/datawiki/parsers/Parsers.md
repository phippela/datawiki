Docker server [(back to home)](../README.md)
===================================
Before you can access please setup [ssh tunnels](../sshtunnels.md).

### background ###

This server is used for running language models. There is simple wrapper build around [**UDPIPE parsers**](http://ufal.mff.cuni.cz/udpipe). This documentation describes how to test that parsers are working. And how to restart docker images when needed.

Currently we have in house trained **finnish** and **swedish** language models for project work. These are trained locally with data sets with allowing licenses. Especially the finnish model can be suplemented with a **'lemmafix' file**. This allows to override and correct wrong lemmas. However, there are many [udpipe language models available](https://lindat.mff.cuni.cz/repository/xmlui/handle/11234/1-2364) and one can also train own models.

Do note that there are available also other parsers (that support CONNLU format). These include **findep parser** from Turku university. There is an image made by Sami Salkosuo. However, do note that even good quality, it is very slow and there are strict licencing restrictions too. 

Of the finnish dep parser, there is also fast variant for lemmas only. This is inhouse development and included in the Salkosuo's parse image. This could be a good candidate for small POCs, where one wants to identify lemmas for short sentences. For example, this could be handy for chat bot or similar POC. There is also possiblity to make findep parser faster for the 'omorfi' information. However, this needs coding effort and Turku people are building a new version.

We have also co-operation with **Lingsoft**, that have extended their finnish parser with CONNLU format. This parser is of good quality and fast. Do note that if we use this in projects we need to ensure that we have rights to use. Please contact Marko Viksten for further details.

### normal operation ###
Normally there are finnish udpipe parser wrapper (omaparser) and pre-anotator tool running:

![Normal docker status](./normaldocker.png?raw=true "Normal docker status")

### testing ###
You can test the parser on port 8080 with:

`time curl -d @testi.txt localhost:8080/parse`

![Parser response](./parserresponse.png?raw=true "Parser response")

The plain text is converted to CONNLU format. Especially the second column is the orignal and third column is the lemma format (i.e. basic form of the word). The lemma format is very handy while creating dictionaries. 



Pre-annotator tool should respond from port 7000:

```
-bash-4.2$ curl localhost:7000 | grep title
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100  4510  100  4510    0     0   373k      0 --:--:-- --:--:-- --:--:--  400k
    <title>Preannotator tool</title>
```

### after boot, if docker service is down ###

As a fi296600 user (TODO move to system user)

```
sudo service docker start
docker run --restart always -d -p 0.0.0.0:8080:8080 omaparser

#please locate the container id
docker ps
sudo docker cp sorted.txt e7d0a2a6f07a:/usr/local/tomcat/lemmafix.txt
sudo docker restart e7d0a2a6f07a

#you can tail the logs with
sudo docker logs -f e7d0a2a6f07a

#after container has loaded logs should print
28-Jun-2018 10:36:29.504 INFO [main] org.apache.catalina.startup.Catalina.start Server startup in 84360 ms

#try that the parser responds to your plain text file
time curl -d @testi.txt localhost:8080/parse

#you can double check that lemma fix is in place by logging
 docker exec -it  e7d0a2a6f07a bash
cat /usr/local/tomcat/lemmafix.txt
```

One could build a new image, so that the container would have the correct lemma fix file already in the start.

To start pre-annotator tool:
```
 sudo docker run -it --rm -d -p 7000:8080 preannotator-tool
```

### tuning lemmafix file ###
Often for dictionary matching, and also for projects, quality of lemmas is of importance.
Adding 'overrides' to finnish language model is easy. Please modify the 'sorted.txt' file - and upload as above.

![Lemma fix](./lemmafix.png?raw=true "Lemma fix")

Do note, that if you are training language models, these 'overrides' can be included in the trained model.
So in theory one can get better and better lemmas from the language models.



[(back to home)](../README.md)